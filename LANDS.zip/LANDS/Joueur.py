import pygame  # importation de pygame dans un espace propre
from pygame.locals import * # constantes dans l'espace global
import Pays as p
import annexe as g
from time import *
import affichage_carte_jeu as a
from random import *

class Joueur :
    
    def __init__(self,id_joueur,nom,couleur, AI=False, niv_AI=0):
        """ Joueur, int, str, int, bool, int -> void
        Préconditions : 0<=niv_AI<=2
        Rôle : constructeur de la classe Joueur"""
        self.nom = nom
        self.id_joueur = id_joueur
        self.couleur = couleur
        self.total_troupes = 30
        self.troupes_a_deployer = 0
        self.atk_success = 0
        self.def_success = 0
        self.territoires_possedes = []
        self.continent_possedes = []
        self.AI = AI
        self.niv_AI = niv_AI
        
    def liste_territoires_possedes(self):
        """ Joueur -> list[Pays]
        Préconditions :
        Rôle : établi la liste de territoire possédés par le joueur""" 
        liste_proprietaire = []
        for pays in p.list_pays_global:
            if pays.proprietaire==self.id_joueur:
                liste_proprietaire.append(pays.id_pays)
        self.territoires_possedes=liste_proprietaire

    def liste_continent_possedes(self):
        """ Joueur -> list[Pays]
        Préconditions :
        Rôle : établi la liste des continents possédés par le joueur"""
        continent_proprietaire = []
        for continent in p.list_continent:
            test_continent=True
            for pays in p.list_pays_global:
                if pays.continent==continent and not pays.proprietaire==self.id_joueur:
                    continent=False
            if test_continent==True:
                continent_proprietaire.append(continent)
        self.continent_possedes = continent_proprietaire
        return continent_proprietaire

    def troupes_par_tour(self):
        """ Joueur -> int
        Préconditions :
        Rôle : calcule le nombre de troupes attribué au joueur à chaque tour en fonction des continents possédés"""
        self.liste_territoires_possedes()
        self.liste_continent_possedes()
        self.troupes_a_deployer+=1+len(self.territoires_possedes)//4
        for continent in self.continent_possedes:
            if continent == "Afrique":
                self.troupes_a_deployer += 3
            if continent == "Asie":
                self.troupes_a_deployer += 6
            if continent ==  "Amérique du Nord":
                self.troupes_a_deployer += 5
            if continent == "Amérique du Sud":
                self.troupes_a_deployer += 3
            if continent == "Europe":
                self.troupes_a_deployer += 4
            if continent == "Océanie":
                self.troupes_a_deployer += 3
    
    def deployer(self, territoire, nombre_troupes_deployer):
        """ Joueur, int, Pays -> void
        Préconditions : nombre_troupes_deployer <= self.troupes_a_deployer, p.list_pays_global[territoire] in self.territoires_possedes
        Rôle : deploie nombre_troupes_deployer troupes dans territoire"""
        self.total_troupes += nombre_troupes_deployer
        self.troupes_a_deployer -= nombre_troupes_deployer
        p.list_pays_global[territoire].troupes_presentes += nombre_troupes_deployer

    def attaquer(self, territoire_depart, territoire_attaque, nombre_troupes):
        """ Joueur, Pays, Pays, int -> void
        Préconditions : nombre_troupes<p.list_pays_global[territoire_attaque].troupes_presentes, p.list_pays_global[territoire_depart] in self.territoires_possedes, p.list_pays_global[territoire_arrivee] not in self.territoires_possedes, territoire_arrivee in p.list_pays_global[territoire_depart].voisins 
        Rôle : attaque territoire_attaque depuis territoire_depart avec le nombre de troupes en paramètres"""
        p.list_pays_global[territoire_depart].troupes_presentes -= nombre_troupes
        self.total_troupes -= nombre_troupes
        troupes_attaque=nombre_troupes
        troupes_defense=p.list_pays_global[territoire_attaque].troupes_presentes
        p.list_pays_global[territoire_attaque].troupes_presentes-=troupes_defense
        liste_joueur[p.list_pays_global[territoire_attaque].proprietaire].total_troupes-=troupes_defense
        while troupes_attaque > 0 and troupes_defense > 0:            
            if troupes_attaque > 2:
                nombresd1 = 3
            elif troupes_attaque == 2:
                nombresd1=2
            else:
                nombresd1=1
            if troupes_defense > 2:
                nombresd2=3
            elif troupes_defense == 2:
                nombresd2=2
            else:
                nombresd2=1
            d1 = []
            d2 = []
            for i in range(nombresd1):
                d1.append(randint(1,6))
            for j in range(nombresd2):
                d2.append(randint(1,6))
            if nombresd1 == 3 and nombresd2 == 3:
                s1 = g.somme(g.max2(d1))
                s2 = g.somme(g.max2(d2))
                if s1 > s2:
                    troupes_defense -= 2
                    if g.maximum(g.max2(d2))==6:
                        troupes_attaque -= 1
                elif s1 == s2:
                    troupes_defense -= 1
                    troupes_attaque -= 1
                else:
                    troupes_attaque -= 2
            elif nombresd1 == 2 and nombresd2 == 3:
                s1 = g.somme(g.max2(d1))
                s2 = g.somme(g.max2(d2))
                if s1 > s2:
                    troupes_defense -= 2
                elif s1 == s2:
                    troupes_defense -= 1
                    troupes_attaque -= 1
                else:
                    troupes_attaque -= 2
            elif nombresd1 == 1 and nombresd2 == 3:
                s1 = d1[0]
                s2 = g.somme(g.max2(d1))
                if s1 > s2:
                    troupes_defense -= 1
                elif s1 == s2:
                    troupes_defense -= 1
                    troupes_attaque -= 1
                else:
                    troupes_attaque -= 1
            elif nombresd1 == 3 and nombresd2 == 1:
                s1 = g.somme(g.max2(d1))
                s2 = g.somme(d2)
                if s1 > s2:
                    troupes_defense -= 1
                elif s1 == s2:
                    troupes_defense -= 1
                    troupes_attaque -= 1
                else:
                    troupes_attaque -= 1      
            elif nombresd1 == 3 and nombresd2 == 2:
                s1 = g.somme(g.max2(d1))
                s2 = g.somme(g.max2(d2))
                if s1 > s2:
                    troupes_defense -= 2
                elif s1 == s2:
                    troupes_defense -= 1
                    troupes_attaque -= 1
                else:
                    troupes_attaque -= 2
            elif nombresd1 == 1 and nombresd2 == 2:
                s1 = g.somme(d1)
                s2 = g.somme(g.max2(d2))
                if s1 > s2:
                    troupes_defense -= 1
                elif s1 == s2:
                    troupes_defense -= 1
                    troupes_attaque -= 1
                else:
                    troupes_attaque -= 1
                           
            elif nombresd1 == 2 and nombresd2 == 2:
                s1 = g.somme(g.max2(d1))
                s2 = g.somme(g.max2(d2))
                if s1 > s2:
                    troupes_defense -= 1                  
                elif s1 == s2:
                    troupes_defense -= 1
                    troupes_attaque -= 1
                else:
                    troupes_attaque -= 1
            elif nombresd1 == 2 and nombresd2 == 1:
                s1 = g.somme(g.max2(d1))
                s2 = g.somme(g.max2(d2))
                if s1 > s2:
                    troupes_defense -= 1          
                elif s1 == s2:
                    troupes_defense -= 1
                    troupes_attaque -= 1           
                else:
                    troupes_attaque -= 1
            elif nombresd1 == 1 and nombresd2 == 1:
                s1 = d1[0]
                s2 = d2[0]
                if s1 > s2:
                    troupes_defense -= 1
                elif s1 < s2:
                    troupes_attaque -= 1
        if troupes_attaque>0:
            p.list_pays_global[territoire_attaque].proprietaire = self.id_joueur
            p.list_pays_global[territoire_attaque].troupes_presentes = 0
            p.list_pays_global[territoire_depart].troupes_presentes += troupes_attaque
            self.total_troupes+=troupes_attaque
            self.atk_success += 1
            return "W"
        else:
            liste_joueur[p.list_pays_global[territoire_attaque].proprietaire].def_success+=1
            p.list_pays_global[territoire_attaque].troupes_presentes+=troupes_defense
            liste_joueur[p.list_pays_global[territoire_attaque].proprietaire].total_troupes+=troupes_defense
            return "L"
                
    def liste_attaque(self):
        """ Joueur -> list
        Préconditions : self.AI=True
        Rôle : établi la liste des attaques possibles"""
        list_attaque=[]
        self.liste_territoires_possedes()
        for pays in self.territoires_possedes:
            for i in p.list_pays_global[pays].voisins:
                if p.list_pays_global[i].proprietaire!=self.id_joueur:
                    if p.list_pays_global[pays].troupes_presentes>1:
                        for j in range(1,p.list_pays_global[pays].troupes_presentes):
                            list_attaque.append((pays,i,j))
        return list_attaque                        
                        
    def liste_deploiement(self):
        """ Joueur -> list
        Préconditions : self.AI=True
        Rôle : établi la liste des déploiements possibles"""
        list_deploiement=[]
        max_deploi=6
        if self.troupes_a_deployer<6:
            max_deploi=self.troupes_a_deployer
        for pays in self.territoires_possedes:
            for i in range(1,max_deploi+1):
                list_deploiement.append((pays,i))
        return list_deploiement      

    def liste_transfere(self):
        """ Joueur -> list
        Préconditions : self.AI=True
        Rôle : établi la liste des transfères possibles"""
        list_transfere=[]
        for pays in self.territoires_possedes:
            for i in p.list_pays_global[pays].voisins:
                if p.list_pays_global[i].proprietaire==self.id_joueur:
                    for j in range(1,p.list_pays_global[pays].troupes_presentes-1):
                        list_transfere.append((pays,i,j))
        return list_transfere
    
    def pourcentage_continent_possedes(self, continent):
        """ Joueur, str -> float
        Préconditions : 
        Rôle : Renvoie le pourcentage du continent possédes par le joueur, (utilisé dans la partie AI)"""
        compteur_pays_possedes=0
        compteur_pays=0
        for id_pays in range(36):
            if p.list_pays_global[id_pays].continent==continent:
                compteur_pays+=1
                if p.list_pays_global[id_pays].proprietaire==self.id_joueur:
                    compteur_pays_possedes+=1
        return compteur_pays_possedes/compteur_pays 

    def efficacite_attaque(self, attaque):
        """ Joueur, list -> float
        Préconditions : self.AI=True
        Rôle : renvoie l'efficacite de l'attaque"""
        efficacite=0
        pourcentagecontinent_jou=liste_joueur[p.list_pays_global[attaque[0]].proprietaire].pourcentage_continent_possedes(p.list_pays_global[attaque[0]].continent)
        pourcentagecontinent_adv=liste_joueur[p.list_pays_global[attaque[1]].proprietaire].pourcentage_continent_possedes(p.list_pays_global[attaque[1]].continent)
        chance_victoire = 0.42 + 0.11 * attaque[2] - 0.09 * p.list_pays_global[attaque[1]].troupes_presentes # Seulement une approximation trouvée sur un forum
        if chance_victoire>0.5:
            if pourcentagecontinent_jou>0.65:
                efficacite+=chance_victoire*8
            if pourcentagecontinent_adv==1:
                efficacite+=chance_victoire*10
            elif pourcentagecontinent_adv>0.7:
                efficacite+=chance_victoire*4
            elif pourcentagecontinent_adv>0.1:
                efficacite+=chance_victoire*5
            efficacite+=chance_victoire*10
        if self.niv_AI==3 and p.list_pays_global[attaque[1]].proprietaire==liste_joueur[0].id_joueur:
            efficacite+=50
        nb_voisin=0
        for id_voisin in p.list_pays_global[attaque[1]].voisins:
            if p.list_pays_global[id_voisin].proprietaire != self.id_joueur :
                chance_victoire_vois=0.42 + 0.11 * (p.list_pays_global[id_voisin].troupes_presentes - 1) - 0.09 * (attaque[2]-1)
                if chance_victoire_vois>0.8:
                    efficacite-=chance_victoire_vois*15
                elif chance_victoire_vois>0.5:
                    efficacite-=chance_victoire_vois*5
        return efficacite

    def efficacite_deploiement(self, deploiement):
        """ self(Joueur), list -> float
        Préconditions : self.AI=True
        Rôle : renvoie l'efficacité du déploiement en paramètre"""
        efficacite=0
        nb_troupes_deploiement=deploiement[1]+p.list_pays_global[deploiement[0]].troupes_presentes
        nb_voisin=0
        for id_voisin in p.list_pays_global[deploiement[0]].voisins:
            if p.list_pays_global[id_voisin].proprietaire != self.id_joueur :
                nb_voisin+=1
                efficacite+=self.efficacite_attaque([deploiement[0], id_voisin, nb_troupes_deploiement - 1])
                efficacite-=liste_joueur[p.list_pays_global[id_voisin].proprietaire].efficacite_attaque((id_voisin, deploiement[0], p.list_pays_global[id_voisin].troupes_presentes - 1))
        if nb_voisin==0:
            return 0
        return efficacite/nb_voisin
    
    def efficacite_transfere(self, transfere):
        """ self(Joueur), list -> float
        Préconditions : self.AI=True
        Rôle : renvoie l'efficacité du transfère en paramètre"""
        nb_troupes_pays_depart=p.list_pays_global[transfere[0]].troupes_presentes-transfere[2]
        nb_troupes_pays_arrive=p.list_pays_global[transfere[1]].troupes_presentes+transfere[2]
        return self.efficacite_deploiement([transfere[0],-1 * nb_troupes_pays_depart])+self.efficacite_deploiement([transfere[1], nb_troupes_pays_arrive])
    
    def choix_deploiement(self):
        """ self(Joueur), int, list -> list
        Préconditions : self.AI=True
        Rôle : Partie AI, réalise le choix du déploiement des troupes en fonction du niveau de l'AI"""
        liste_deploiement=self.liste_deploiement()
        niv_AI=self.niv_AI
        if niv_AI>=2:
            list_efficacite_deploiement=[]
            for deploiement in liste_deploiement:
                list_efficacite_deploiement.append(self.efficacite_deploiement(deploiement))
            maxi=list_efficacite_deploiement[0]
            ind_max=0
            for i in range(len(list_efficacite_deploiement)):
                if list_efficacite_deploiement[i]>maxi:
                    ind_max=i
                    maxi=list_efficacite_deploiement[i]
            return liste_deploiement[ind_max]
        else:
            deploiement_random=randint(0,len(liste_deploiement)-1)
            return liste_deploiement[deploiement_random] 

    def choix_attaque(self):
        """ self(Joueur), -> list
        Préconditions : self.AI=True
        Rôle : Partie AI, réalise le choix d'attaque en fonction du niveau de l'AI"""
        liste_attaque=self.liste_attaque()
        niv_AI=self.niv_AI
        if niv_AI>=2:
            list_efficacite_attaque=[]
            for attaque in liste_attaque:
                list_efficacite_attaque.append(self.efficacite_attaque(attaque))
            if list_efficacite_attaque==[]:
                return 0
            maxi=list_efficacite_attaque[0]
            ind_max=0
            for i in range(len(list_efficacite_attaque)):
                if list_efficacite_attaque[i]>maxi:
                    ind_max=i
                    maxi=list_efficacite_attaque[i]
            return liste_attaque[ind_max]
        else:
            attaque_random=randint(0,len(liste_attaque)-1)
            return liste_attaque[attaque_random] 
                
    def choix_transfere(self):
        """ self(Joueur) -> list
        Préconditions :
        Rôle : Partie AI, réalise le choix de transfère de troupes en fonction du niveau de l'AI"""
        liste_transfere=self.liste_transfere()
        niv_AI=self.niv_AI
        if niv_AI>=2:
            list_efficacite_transfere=[]
            for transfere in liste_transfere:
                list_efficacite_transfere.append(self.efficacite_transfere(transfere))
            if list_efficacite_transfere==[]:
                return 0
            maxi=list_efficacite_transfere[0]
            ind_max=0
            for i in range(len(list_efficacite_transfere)):
                if list_efficacite_transfere[i]>maxi:
                    ind_max=i
                    maxi=list_efficacite_transfere[i]
            return liste_transfere[ind_max]
        else:
            transfere_fait=random()
            if transfere_fait>0.85:
                if liste_transfere!=[]:
                    transfere_random=randint(0,len(liste_transfere)-1)
                    return liste_transfere[transfere_random] 
            return 0
        
    def tests(self, id_territoire):
        """ self(Joueur), int -> bool
        Préconditions : p.list_pays_global[id_territoire] in self.territoires_possedes
        Rôle : test si le pays a des voisins qui ne sont pas en possession du joueur et si le pays a plus de une troupe"""
        if id_territoire==-1:
            return True
        if p.list_pays_global[id_territoire].troupes_presentes>1:
            for voisins in p.list_pays_global[id_territoire].voisins:
                if p.list_pays_global[voisins].proprietaire != self.id_joueur :
                    return False
        return True
            
    def attaque_impossible(self):
        """ self(Joueur) -> bool
        Préconditions :
        Rôle : test si le joueur peut réalisé une attaque"""
        self.liste_territoires_possedes()
        for pays in self.territoires_possedes:
            for voisin in p.list_pays_global[pays].voisins:
                if p.list_pays_global[pays].troupes_presentes>1 and p.list_pays_global[voisin].proprietaire!=self.id_joueur:
                    return False
        return True
    
    def transfere_impossible(self):
        """ self(Joueur) -> bool
        Préconditions : 
        Rôle : test si le joueur peut réalisé un transfère"""
        self.liste_territoires_possedes()
        for pays in self.territoires_possedes:
            for voisin in p.list_pays_global[pays].voisins:
                if p.list_pays_global[pays].troupes_presentes>1 and p.list_pays_global[voisin].proprietaire==self.id_joueur:
                    return False
        return True
    
    def tour_deploiement_joueur(self):
        """ Joueur -> void
        Préconditions : self.total_troupes>0
        Rôle : phase attaque du tour / partie joueur"""
        while self.troupes_a_deployer>0:
            a.affichage_map(liste_joueur,0)
            a.affichage_info(8)
            a.affichage_troupes_dep(str(self.troupes_a_deployer))
            selec_territoire=-1
            while selec_territoire not in self.territoires_possedes:
                selec_territoire=a.selection_territoire(0)
                if selec_territoire==-2:
                    self.tour_deploiement_joueur()
            if self.troupes_a_deployer==1:
                self.deployer(selec_territoire,1)
            else:
                selec_troupes=a.selection_troupe(1,self.troupes_a_deployer)
                if selec_troupes==-2:
                    self.tour_deploiement_joueur()
                else:
                    self.deployer(selec_territoire,selec_troupes)
    
    def tour_attaque_joueur(self):
        """ Joueur -> void
        Préconditions : self.total_troupes>0
        Rôle : phase attaque du tour / partie joueur"""
        a.affichage_map(liste_joueur,1)
        a.affichage_info(9)
        self.liste_territoires_possedes()
        # SELECTION TERRITOIRE DEPART ET ATTAQUE
        selec_territoire_depart=-1
        selec_territoire_attaque=-1
        while selec_territoire_depart not in self.territoires_possedes or self.tests(selec_territoire_depart) or selec_territoire_depart==-1 or selec_territoire_attaque not in p.list_pays_global[selec_territoire_depart].voisins or selec_territoire_attaque in self.territoires_possedes or selec_territoire_attaque==-1 :
            selec_territoire_depart, selec_territoire_attaque=a.selection_territoire(1)
            if selec_territoire_depart==-2:
                self.tour_attaque_joueur()
        # SELECTION DE TROUPES
        a.affichage_info(4)
        selec_troupes=a.selection_troupe(1,p.list_pays_global[selec_territoire_depart].troupes_presentes-1)
        if selec_troupes==-2:
            self.tour_attaque_joueur()
        test=self.attaquer(selec_territoire_depart, selec_territoire_attaque, selec_troupes)
        test_defaite=test=="W"
        a.affichage_map(liste_joueur,1)
        # NOMBRE TROUPES APRES VICTOIRE
        if test == "W":
            a.affichage_info(5)
            selec_troupes_territoire_gagne=a.selection_troupe(1,selec_troupes)
            p.list_pays_global[selec_territoire_depart].troupes_presentes-=selec_troupes_territoire_gagne
            p.list_pays_global[selec_territoire_attaque].troupes_presentes+=selec_troupes_territoire_gagne
        a.affichage_map(liste_joueur,1)
        return test
    
    def tour_transfere_joueur(self):
        """ Joueur -> void
        Préconditions : self.total_troupes>0
        Rôle : phase attaque du tour / partie joueur"""
        a.affichage_map(liste_joueur,2)
        a.affichage_info(10)
        self.liste_territoires_possedes()
        selec_territoire_transfere=-1
        selec_territoire_transfere2=-1
        while selec_territoire_transfere==-1 or selec_territoire_transfere2 not in self.territoires_possedes or selec_territoire_transfere2 not in p.list_pays_global[selec_territoire_transfere].voisins or selec_territoire_transfere2==1 :
            selec_territoire_transfere, selec_territoire_transfere2=a.selection_territoire(2)
            if selec_territoire_transfere==-2:
                self.tour_transfere_joueur()
            a.affichage_info(7)
            selec_troupes_trans=a.selection_troupe(1,p.list_pays_global[selec_territoire_transfere].troupes_presentes-1)
            if selec_troupes_trans==-2:
                self.tour_transfere_joueur()
        p.list_pays_global[selec_territoire_transfere].transferer(selec_territoire_transfere2,selec_troupes_trans)   
# # # # # #


def repartition_depart():
    """ void -> void
    Préconditions :
    Rôle : réalise la répartition des territoires du début de jeu"""
    liste_pays=[]
    troupes_a_deployer=[]
    for i in range(4):
        troupes_a_deployer.append([1,1,3,4,5,5,2,2,7])
    for i in range(36):
        liste_pays.append(i)
    territoire_reparti=0
    while liste_pays!=[""]*36:
        for i in range(4):
            pays_choisis=-1
            while pays_choisis==-1 or liste_pays[pays_choisis]=="":
                pays_choisis=randint(0,35)
            territoire_reparti+=1
            p.list_pays_global[pays_choisis].proprietaire=i
            liste_pays[pays_choisis]=""
            while p.list_pays_global[pays_choisis].troupes_presentes==0:
                id_troupe=randint(0,8)
                p.list_pays_global[pays_choisis].troupes_presentes=troupes_a_deployer[i][id_troupe]
                troupes_a_deployer[i][id_troupe]=0


def tour():
    """ void -> void
    Préconditions :
    Rôle : tour du jeu avec deploiement / attaque / transfere par chaque joueur"""
    #Deploiement
    for joueur in liste_joueur:
        if joueur.total_troupes>0:
            a.affichage_map(liste_joueur,0)  
            joueur.liste_territoires_possedes()
            joueur.troupes_par_tour()
            if joueur.AI==True:
                if joueur.attaque_impossible():
                    for pays in joueur.territoires_possedes:
                        for voisin in p.list_pays_global[pays].voisins:
                            if p.list_pays_global[pays].troupes_presentes==1 and p.list_pays_global[voisin].proprietaire!=joueur.id_joueur:
                                joueur.deployer(pays,joueur.troupes_a_deployer)
                while joueur.troupes_a_deployer>0:
                    deploiement=joueur.choix_deploiement()
                    joueur.deployer(deploiement[0],deploiement[1])
            else:
                joueur.tour_deploiement_joueur()
    for joueur in liste_joueur:
        if joueur.total_troupes>0:
            joueur.liste_territoires_possedes()
            test_defaite=True
            a.affichage_map(liste_joueur,1)
            while test_defaite==True and not joueur.attaque_impossible():
                if joueur.AI==True:
                    attaque=joueur.choix_attaque()
                    if attaque is not 0:
                        test=joueur.attaquer(attaque[0],attaque[1],attaque[2])
                        test_defaite=test=="W"
                        if test == "W":
                            nombre_troupes_territoire_gagne=randint(1,p.list_pays_global[attaque[0]].troupes_presentes-1)
                            p.list_pays_global[attaque[0]].troupes_presentes-=nombre_troupes_territoire_gagne
                            p.list_pays_global[attaque[1]].troupes_presentes+=nombre_troupes_territoire_gagne
                else:
                    if a.test_continuer():
                        test=joueur.tour_attaque_joueur()
                        test_defaite=test=="W"
                    else:
                        test_defaite=False
    for joueur in liste_joueur:
        if joueur.total_troupes>0:
            if not joueur.transfere_impossible():
                a.affichage_map(liste_joueur,2)  
                if joueur.AI==True:
                    transfere_choisi=joueur.choix_transfere()
                    if transfere_choisi is not 0:
                        p.list_pays_global[transfere_choisi[0]].transferer(transfere_choisi[1],transfere_choisi[2])
                else:
                    if a.test_continuer():
                        joueur.tour_transfere_joueur()
    return liste_joueur


def debut_partie(nom, ID_couleur, nivAI):
    """self(Joueur), int, int -> list
    Préconditions :
    Rôle : Début de la partie de jeu"""
    global liste_joueur
    couleur = ["yellow","green","blue","red"]
    J1=Joueur(0,nom, couleur.pop(ID_couleur))
    J2=Joueur(1,"Napoleon",couleur.pop(),AI=True, niv_AI=nivAI)
    J3=Joueur(2,"Colomb",couleur.pop(),AI=True, niv_AI=nivAI)
    J4=Joueur(3,"Magellan",couleur.pop(),AI=True, niv_AI=nivAI)
    liste_joueur=[J1,J2,J3,J4]
    repartition_depart()
    return liste_joueur
