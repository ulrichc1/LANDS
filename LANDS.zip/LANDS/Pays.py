class Pays:
    
    def __init__(self, id_pays, nom, continent, liste_voisins):
        """Pays, str, str -> void
        Préconditions :
        Rôle : constructeur de classe Pays"""
        self.id_pays=id_pays
        self.nom=nom
        self.continent=continent
        self.voisins=liste_voisins
        self.proprietaire=""
        self.troupes_presentes=0
        
    def est_voisins(self, voisin_teste):
        """Pays, Pays -> bool
        Préconditions :
        Rôle : teste si un pays est voisin de l'autre"""
        return voisin_teste.id_pays in self.voisins
    
    def transferer(self, pays_arrive, nombre_troupes_transferer):
        """Pays, Pays -> void
        Préconditions : self.proprietaire == pays_arrive.proprietaire, self.est_voisins(pays_arrive) == True, 
        Rôle : transfère des troupes d'un pays à un autre"""
        self.troupes_presentes-=nombre_troupes_transferer
        list_pays_global[pays_arrive].troupes_presentes+=nombre_troupes_transferer
        
    def attaque_possible(self,pays_attaque):
        if self.id_pays in pays_attaque.voisins:
            return True
        return False
            
list_continent=["Amérique du Nord", "Amérique du Sud", "Afrique", "Europe", "Océanie", "Asie"]
Alaska=Pays(0, "Alaska", list_continent[0], [2,1,28])
CanadaNord=Pays(1, "Canada Nord", list_continent[0], [0,2,3,4])
CanadaOuest=Pays(2, "Canada Ouest", list_continent[0], [0,1,3,5])
CanadaEst=Pays(3, "Canada Est", list_continent[0], [1,2,5,6])
Groenland=Pays(4, "Groenland", list_continent[0], [3,17,1])
USA_Ouest=Pays(5, "Etats-Unis Ouest", list_continent[0], [2,3,6,7])
USA_Est=Pays(6, "Etats-Unis Est", list_continent[0], [7,3,5])
Mexique=Pays(7, "Méxique", list_continent[0], [6,5,8])
Colombie=Pays(8, "Colombie", list_continent[1], [7,9,10])
Bresil=Pays(9, "Brésil", list_continent[1], [10,8,11,12])
Perou=Pays(10, "Pérou", list_continent[1], [8,9,11])
Argentine=Pays(11, "Argentine", list_continent[1], [10,9])
AfriqueOuest=Pays(12, "Afrique Ouest", list_continent[2], [9,13,14,16])
Egypte=Pays(13, "Egypte", list_continent[2], [12,14,20,32])
AfriqueCentrale=Pays(14, "Afrique Centrale", list_continent[2], [12,13,15])
AfriqueSud=Pays(15, "Afrique du Sud", list_continent[2], [14])
EuropeOuest=Pays(16, "Europe de l'Ouest", list_continent[3], [12,20,19,17])
RoyaumeUni=Pays(17, "Royaume-Uni", list_continent[3], [4,18,16,19])
Scandinavie=Pays(18, "Scandinavie", list_continent[3], [19,21,17])
EuropeCentrale=Pays(19, "Europe Centrale", list_continent[3], [20,16,21,18,17])
EuropeSud=Pays(20, "Europe du Sud", list_continent[3], [19,16,21,13,32])
Ukraine=Pays(21, "Ukraine", list_continent[3], [19,18,20,30,26,32])
Indonesie=Pays(22, "Indonésie", list_continent[4], [34,23,24,25])
NouvelleGuinee=Pays(23, "Nouvelle-Guinée", list_continent[4], [22,24,25])
AustralieOuest=Pays(24, "Australie Ouest", list_continent[4], [25,22])
AustralieEst=Pays(25, "Australie Est", list_continent[4], [22,24])
Siberie=Pays(26, "Sibérie", list_continent[5], [21,30,31,29,27])
Yakutia=Pays(27, "Yakutia", list_continent[5], [29,26,28])
Chukotka=Pays(28, "Chukotka", list_continent[5], [27,29,35,0])
Mongolie=Pays(29, "Mongolie", list_continent[5], [27,26,31,35,28])
Kazahstan=Pays(30, "Kazahstan", list_continent[5], [21,32,26,31,33])
Chine=Pays(31, "Chine", list_continent[5], [29,26,30,33,34])
MoyenOrient=Pays(32, "Moyen-Orient", list_continent[5], [13,20,30,33])
Inde=Pays(33, "Inde", list_continent[5], [32,30,31,34])
AsieSud=Pays(34, "Asie Sud-Est", list_continent[5], [22,33,31])
Japon=Pays(35, "Japon", list_continent[5], [29,28])
list_pays_global=[Alaska, CanadaNord,CanadaOuest,CanadaEst, Groenland, USA_Ouest, USA_Est, Mexique, Colombie, Bresil, Perou, Argentine, AfriqueOuest, Egypte, AfriqueCentrale, AfriqueSud,
           EuropeOuest, RoyaumeUni, Scandinavie, EuropeCentrale, EuropeSud, Ukraine, Indonesie, NouvelleGuinee, AustralieOuest, AustralieEst, Siberie, Yakutia, Chukotka, Mongolie,
           Kazahstan, Chine, MoyenOrient, Inde, AsieSud, Japon]
