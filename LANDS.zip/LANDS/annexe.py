from random import*

def somme(tab):
    """ list[int] -> int
    Préconditions : 
    Rôle : renvoie la somme du tableau"""
    somme = 0
    for i in range(len(tab)):
        somme += tab[i]
    return somme
        
def maximum(tab):
    """ list[int] -> int
    Préconditions : tab!=[]
    Rôle : renvoie le maximum du tableau"""
    maxi = tab[0]
    n = len(tab)
    for i in range(n):
        if tab[i] > maxi:
            maxi = tab[i]
            ind = i
    return maxi

def max2(tab):
    """ list[int] -> list[int]
    Préconditions :
    Rôle : renvoie une liste avec les deux valeurs maximal du tableau"""
    maxis = []
    n = len(tab)
    if n >= 2:
        maxi1 = maximum(tab)
        maxis.append(maxi1)
        maxi2 = maximum(tab)
        maxis.append(maxi2)
    elif n == 1:
        maxi1 = maximum(tab)
        maxis.append(maxi1)
    return maxis

