import pygame 
from affichage_carte_jeu import *
from pygame.locals import *
from time import *
pygame.init()  

# dimensions de la fenêtre
largeur = 1366
hauteur = 690
noir = (0 , 0 , 0)

def ecran_titre_niveau(niv):
    """ int -> void
    Préconditions : 
    Rôle : partie selection niveau de l'écran titre"""
    if niv==0:
        fenetre.blit(niv1_off,(293,460))
        fenetre.blit(niv2_off,(590,460))
        fenetre.blit(niv3_off,(900,460))
    if niv==1:
        fenetre.blit(niv1_on,(293,460))
        fenetre.blit(niv2_off,(590,460))
        fenetre.blit(niv3_off,(900,460))
    if niv==2:
        fenetre.blit(niv1_off,(293,460))
        fenetre.blit(niv2_on,(590,460))
        fenetre.blit(niv3_off,(900,460))
    if niv==3:
        fenetre.blit(niv1_off,(293,460))
        fenetre.blit(niv2_off,(590,460))
        fenetre.blit(niv3_on,(900,460))
    pygame.display.flip()

def ecran_titre_invariable():
    """ void -> void
    Préconditions : 
    Rôle : affiche l'écran titre """
    fenetre.blit(fond,(0,0))
    fenetre.blit(bouton_credit,(20,80))
    fenetre.blit(bouton_regle,(20,20))
    fenetre.blit(logo,(315,30))
    bouton_start= pygame.image.load("Start.png").convert_alpha()
    fenetre.blit ( bouton_start ,( 535 ,580 ) )

def ecran_titre_couleur(id_couleur):
    """ int -> void
    Préconditions : 
    Rôle : Affichage de la selection de couleur de l'écran titre"""
    if couleur==0:
        pygame.draw.rect( fenetre , "white" , (238, 247, 190 , 110 ) )
    if couleur==1:
        pygame.draw.rect( fenetre , "white" , (458, 247, 190 , 110 ))
    if couleur==2:
        pygame.draw.rect( fenetre , "white" , (678, 247, 190 , 110 ) )
    if couleur==3:
        pygame.draw.rect( fenetre , "white" , (898, 247, 190 , 110 ) )
    pygame.draw.rect( fenetre , "yellow" , (243,252 , 180 , 100 ) )
    pygame.draw.rect( fenetre , "green" , (463, 252, 180 , 100 ) )
    pygame.draw.rect( fenetre , "blue" , (683, 252,180 , 100 ) )
    pygame.draw.rect( fenetre , "red" , (903, 252, 180 , 100 ) )
    pygame.display.flip()

def selection_couleur(x,y,couleur):
    """ int, int, int -> int
    Préconditions : 
    Rôle : Interaction du joueur avec la selection de couleur"""
    if 243<x<243+180 and 252<y<352:       
        couleur=0 
    if 463<x<463+180 and 252<y<352:
        couleur=1
    if 683<x<683+180 and 252<y<352:
        couleur=2
    if 903<x<1083 and 252<y<352:
        couleur=3
    return couleur

def niveauAI(x,y,niv):
    """ int,int,int -> int
    Préconditions : 
    Rôle : Interaction du joueur avec la selection du niveau"""
    if 293<=x<=293+146 and 460<=y<=549:         
        niv=1
    if 590<=x<=590+146 and 460<=y<=549:
        niv=2
    if 900<=x<=900+146 and 460<=y<=549:
        niv=3
    return niv
    
def ecran_regle():
    """ void -> void
    Préconditions : si 
    Rôle : affiche la page indiquant les règles du jeu"""
    fenetre.fill("black")
    bouton_croix = pygame.image.load("croix.png").convert_alpha()
    regles=pygame.image.load("regles.png").convert_alpha()
    fenetre.blit(bouton_croix,(20,20))
    fenetre.blit(regles,(0,0))
    pygame.display.flip()
    
def ecran_credit():
    """ void -> void
    Préconditions : 
    Rôle : affiche la page indiquant les crédits"""
    fenetre.fill("black")
    bouton_croix = pygame.image.load("croix.png").convert_alpha()
    credit = pygame.image.load("credits.png").convert_alpha()
    fenetre.blit(bouton_croix,(20,20))
    fenetre.blit(credit,(0,0))
    pygame.display.flip()            
            
def bouton_spe(x,y,bouton_cliquer):
    """ int, int, bool -> bool
    Préconditions : 
    Rôle : interaction des boutons règle du jeu et crédits"""
    if 20<x<100 and 20<y<70 and bouton_cliquer==False:
        ecran_regle()
        pygame.display.flip()
        bouton_cliquer=True
    elif 0<x<60 and 0<y<60 and bouton_cliquer==True:
        ecran_titre_invariable()
        ecran_titre_couleur(couleur)
        ecran_titre_niveau(niv)
        pygame.display.flip()
        bouton_cliquer = False
    elif 20<x<100 and 80<y<130 and bouton_cliquer==False:
        ecran_credit()
        bouton_cliquer=True
    return bouton_cliquer


try:
    global couleur
    global niv
    global bouton_cliquer
    bouton_cliquer=False
    couleur=-1
    niv=0
    niv1_off=pygame.image.load("niv1_off.png").convert()
    niv1_on=pygame.image.load("niv1_on.png").convert()
    niv2_off=pygame.image.load("niv2_off.png").convert()
    niv2_on=pygame.image.load("niv2_on.png").convert()
    niv3_off=pygame.image.load("niv3_off.png").convert()
    niv3_on=pygame.image.load("niv3_on.png").convert()
    fenetre = pygame.display.set_mode((largeur,hauteur))  
    fond = pygame.image.load("FondTitre.jpg").convert() # Fond de l'écran de départ
    logo= pygame.image.load("LANDS.png").convert_alpha() # Logo du jeu
    bouton_credit = pygame.image.load("BouttonC.png").convert_alpha() # Boutton pour accéder au crédits
    bouton_regle = pygame.image.load("BouttonRegle.png").convert_alpha() # Boutton pour accéder aux règles du jeu
    ecran_titre_invariable()
    ecran_titre_couleur(couleur) 
    ecran_titre_niveau(niv)
    bouton_cliquer=False
    pygame.display.flip()     
    continuer = True
    while continuer:
        # gestionnaire d'événements :
        for event in pygame.event.get():
            if event.type==QUIT: # clic sur la croix
                continuer = False # fin de la boucle
            if event.type==MOUSEBUTTONDOWN :
                (x, y) = event.pos
                if not bouton_cliquer:
                    couleur=selection_couleur(x,y,couleur)
                    niv=niveauAI(x,y,niv)
                    ecran_titre_invariable()
                    ecran_titre_couleur(couleur)
                    ecran_titre_niveau(niv)
                    bouton_cliquer=bouton_spe(x,y,bouton_cliquer)
                    pygame.display.flip()
                    if couleur>-1 and niv>0:
                        if 535<x<785 and 580<y<680:
                            jeu(couleur, niv)
                else:
                    bouton_cliquer=bouton_spe(x,y,bouton_cliquer)
                
finally:
    pygame.quit() # Fermeture de Pygame