import pygame
import Joueur as j
import Pays as p
from time import *
from random import *
global liste_bouton

from pygame.locals import * 
pygame.init()  
global fenetre
# dimensions de la fenêtre
largeur = 1366
hauteur = 690
noir = (0 , 0 , 0)
fenetre = pygame.display.set_mode((largeur,hauteur))
couleur = [(255,0,0),(0,255,0),(0,255,0),(0,0,255)]

def affiche_boutton(liste_de_bouton, liste_joueur):
    """int, int, int -> void
    Préconditions :
    Rôle : affiche la liste des bouttons correspondant à chaque pays au bonne coordonnées"""
    font_boutton=pygame.font.SysFont("Calibri", 20, bold=True, italic=False)
    for i in range(len(liste_bouton)):
        texte1=font_boutton.render(str(p.list_pays_global[liste_bouton[i][0]].troupes_presentes),1,"black")
        pygame.draw.circle(fenetre,liste_joueur[p.list_pays_global[liste_bouton[i][0]].proprietaire].couleur,(liste_bouton[i][1],liste_bouton[i][2]), 20)
        pygame.draw.circle(fenetre,(0,0,0),(liste_bouton[i][1],liste_bouton[i][2]), 20, width=2)
        fenetre.blit(texte1,(liste_bouton[i][1]-5,liste_bouton[i][2]-8))

B0= 0, 106, 68
B1= 1, 218, 61
B2=2,182,108
B3=3,301,116
B4=4,472,54
B5=5,166,165
B6=6,270,174
B7=7,160,233
B8=8,298,301
B9=9,385,360
B10=10,278,370
B11=11,337,452
B12=12,592,302
B13=13,704,275
B14=14,717,356
B15=15,706,460
B16=16,577,200
B17=17,573,145
B18=18,671,106
B19=19,670,157
B20=20,669,205
B21=21,765,149
B22=22,1097,385
B23=23,1200,335
B24=24,1178,432
B25=25,1275,433
B26=26,920,135
B27=27,1044,115
B28=28,1161,137
B29=29,1073,177
B30=30,862,198
B31=31,1022,241
B32=32,782,247
B33=33,952,284
B34=34,1057,310
B35=35,1204,234

liste_bouton=[B0,B1,B2,B3,B4,B5,B6,B7,B8,B9,B10,B11,B12,B13,B14,B15,B16,B17,B18,B19,B20,B21,B22,B23,B24,B25,B26,B27,B28,B29,B30,B31,B32,B33,B34,B35]

def selection_territoire(phase):
    """ int -> void
    Préconditions : 0<=phase<=2, 0 = deploiement, 1 = attaque, 2 = transfere
    Rôle : sélection du territoire par le joueur"""
    if phase==0:
        id_selection=-1
        while True:
            for event in pygame.event.get():
                if event.type==QUIT: # clic sur la croix
                    pygame.quit()
                if event.type==MOUSEBUTTONDOWN: # clic sur la croix
                    (x, y) = event.pos
                    for i in range(len(liste_bouton)):
                        if liste_bouton[i][1]-20<x<liste_bouton[i][1]+20 and liste_bouton[i][2]-20<y<liste_bouton[i][2]+20:
                            id_selection=liste_bouton[i][0]
                            if phase==0:
                                affichage_info(0,texte1=str(p.list_pays_global[id_selection].nom))
                if event.type == KEYDOWN:
                    if event.key == K_ESCAPE:
                        return -2
                    if event.key == K_RETURN:
                        if id_selection!=-1:
                            return id_selection
    else:
        id_selection1=-1
        id_selection2=-1
        while True:
            for event in pygame.event.get():
                if event.type==QUIT: # clic sur la croix
                    pygame.quit()
                if event.type==MOUSEBUTTONDOWN: # clic sur la croix
                    (x, y) = event.pos
                    for i in range(len(liste_bouton)):
                        if liste_bouton[i][1]-20<x<liste_bouton[i][1]+20 and liste_bouton[i][2]-20<y<liste_bouton[i][2]+20:
                            id_selection1=liste_bouton[i][0]
                            if phase==1:
                                if id_selection1==-1:
                                    affichage_info(3,texte1="0",texte2="0")
                                else:
                                    affichage_info(3,texte1=str(p.list_pays_global[id_selection1].nom),texte2="0")
                            else:
                                if id_selection1==-1:
                                    affichage_info(3,texte1="0",texte2="0")
                                else:
                                    affichage_info(6,texte1=str(p.list_pays_global[id_selection1].nom),texte2="0")
                if event.type == KEYDOWN:
                    if event.key == K_ESCAPE:
                        return -2,0
                    if event.key == K_RETURN:
                        if id_selection1!=-1:
                            while True:
                                for event in pygame.event.get():
                                    if event.type==QUIT: # clic sur la croix
                                        pygame.quit()
                                    if event.type==MOUSEBUTTONDOWN: # clic sur la croix
                                        (x, y) = event.pos
                                        for i in range(len(liste_bouton)):
                                            if liste_bouton[i][1]-20<x<liste_bouton[i][1]+20 and liste_bouton[i][2]-20<y<liste_bouton[i][2]+20:
                                                id_selection2=liste_bouton[i][0]
                                                if phase==1:
                                                    affichage_info(3,texte1=str(p.list_pays_global[id_selection1].nom),texte2=str(p.list_pays_global[id_selection2].nom))
                                                else:
                                                    affichage_info(6,texte1=str(p.list_pays_global[id_selection1].nom),texte2=str(p.list_pays_global[id_selection2].nom))
                                    if event.type == KEYDOWN:
                                        if event.key == K_ESCAPE:
                                            return -2,0
                                        if event.key == K_RETURN:
                                            if id_selection2!=-1:
                                                return id_selection1, id_selection2
        
def affichage_info(mode, texte1="", texte2=""):
    """ str -> void
    Préconditions : 0<=mode<=10
    Rôle : Affichage de divers informations sur la partie dans la zone en bas"""
    zonebas=pygame.image.load("ZoneBas.png").convert_alpha()
    fenetre.blit(zonebas,(0,582))
    pygame.display.flip()
    appuyez_passer=pygame.image.load("AppuyezPasser.png").convert_alpha()
    entrer_echapper=pygame.image.load("ENTESC.png").convert_alpha()
    selectroupesattaque=pygame.image.load("selectroupesattaque.png").convert_alpha()
    selectroupesdeploiement=pygame.image.load("selectroupesdeploiement.png").convert_alpha()
    selectroupestransfere=pygame.image.load("selectroupestransfere.png").convert_alpha()
    selectroupesvictoire=pygame.image.load("selectroupesvictoire.png").convert_alpha()
    territoireselection=pygame.image.load("TerritoireSelection.png").convert_alpha()
    doubleselectransfere=pygame.image.load("DoubleSelecTransfere.png").convert_alpha()
    doubleselecattaque=pygame.image.load("DoubleSelecAttaque.png").convert_alpha()
    info_deploiement=pygame.image.load("InfoDep.png").convert_alpha()
    info_attaque=pygame.image.load("InfoAtt.png").convert_alpha()
    info_transfere=pygame.image.load("InfoTrans.png").convert_alpha()
    if texte1!="":
        font = pygame.font.SysFont( " calibri " , 25 , bold = True)
        texte_info1 = font.render(texte1,1,"black")
    if texte2!="":
        font = pygame.font.SysFont( " calibri " , 25 , bold = True)
        texte_info2 = font.render(texte2,1,"black")
    if mode==0:
        fenetre.blit(entrer_echapper,(0,0))
        fenetre.blit(territoireselection,(0,0))
        fenetre.blit(texte_info1,(760,640))
    if mode==1:
        fenetre.blit(entrer_echapper,(0,0))
        fenetre.blit(selectroupesdeploiement,(0,0))
    if mode==2:
        fenetre.blit(appuyez_passer,(0,0))
    if mode==3:
        fenetre.blit(entrer_echapper,(0,0))
        fenetre.blit(doubleselecattaque,(0,0))
        fenetre.blit(texte_info1,(280,657))
        fenetre.blit(texte_info2,(907,657))
    if mode==4:
        fenetre.blit(entrer_echapper,(0,0))
        fenetre.blit(selectroupesattaque,(0,0))
    if mode==5:
        fenetre.blit(selectroupesvictoire,(0,0))
    if mode==6:
        fenetre.blit(entrer_echapper,(0,0))
        fenetre.blit(doubleselectransfere,(0,0))
        fenetre.blit(texte_info1,(280,657))
        fenetre.blit(texte_info2,(907,657))
    if mode==7:
        fenetre.blit(selectroupestransfere,(0,0))
    if mode==8:
        fenetre.blit(info_deploiement,(0,0))
    if mode==9:
        fenetre.blit(info_attaque,(0,0))
    if mode==10:
        fenetre.blit(info_transfere,(0,0))
    pygame.display.flip()

def selection_troupe(mini,maxi):
    """ void -> int
    Préconditions :
    Rôle : sélection de troupes par le joueur"""
    def carre(x):
        """ int -> void
        Préconditions :
        Rôle : dessine un carré blanc de côté 40 avec un contour noir"""
        pygame.draw.rect( fenetre , "black" , (x,528 , 50 , 50 ))
        pygame.draw.rect( fenetre , "white" , (x+5,533 , 40 , 40 ))
    troupe=mini
    font = pygame.font.SysFont( " calibri " , 50 , bold = False , italic =
    False )
    texte1 = font.render( "+" , 1 , noir )
    texte2 = font.render( "-" , 1 , noir )
    texte3 = font.render( str(mini) , 1 , noir )
    carre(658)
    fenetre.blit ( texte3 ,(670,533  ) )
    #bouton +
    carre(718)
    fenetre.blit ( texte1 ,( 728 ,528 ) )
    #bouton -
    carre(598)
    fenetre.blit ( texte2 ,(612,528  ) )
    pygame.display.flip()
    continuer=True
    while continuer:
        for event in pygame.event.get():
            if event.type==QUIT: # clic sur la croix
                pygame.quit()
            if event.type==MOUSEBUTTONDOWN:
                (x, y) = event.pos
                if 728<x<778 and 528<y<578:
                    if troupe!=maxi:
                        troupe+=1
                        texte3 = font.render( str(troupe) , 1 , noir )
                        carre(658)
                        if troupe>=10:
                            fenetre.blit ( texte3 ,(660,533  ) )
                        else:
                            fenetre.blit ( texte3 ,(670,533  ) )
                        #bouton +
                        carre(718)
                        fenetre.blit ( texte1 ,( 730 ,528 ) )
                        #bouton -
                        carre(598)
                        fenetre.blit ( texte2 ,(612,528  ) )
                        pygame.display.flip()
                if 608<x<658 and 528<y<578 :
                    if troupe!=mini:
                        troupe-=1
                        texte3 = font.render( str(troupe) , 1 , noir )
                        carre(658)
                        if troupe>=10:
                            fenetre.blit ( texte3 ,(660,533  ) )
                        else:
                            fenetre.blit ( texte3 ,(670,533  ) )
                        #bouton +
                        carre(718)
                        fenetre.blit ( texte1 ,( 730 ,528 ) )
                        #bouton -
                        carre(598)
                        fenetre.blit ( texte2 ,(612,528  ) )
                        pygame.display.flip()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    return -2
                if event.key == K_RETURN :
                    if mini<=troupe<=maxi:
                        return troupe
def affichage_troupes_dep(troupes):
    """ str - > void
    Préconditions :
    Rôle : affichage le nombre de troupes à deployer sur l'écran, en bas à droite"""
    font = pygame.font.SysFont( " calibri " , 50 , bold = True)
    texte_troupes = font.render(troupes,1,"black")
    fenetre.blit (texte_troupes,(1292,615))
    pygame.display.flip()

def affichage_map(liste_joueur,phase):
    """ list[Joueur] -> void
    Préconidtions : 0<=phase<=2
    Rôle : Affiche la carte de jeu"""
    fenetre.fill("white")
    fenetre.blit(fond,(0,0))
    affiche_boutton(liste_bouton, liste_joueur)
    font = pygame.font.SysFont( " calibri " , 24 , bold = True)
    if phase==0:
        texte_phase=font.render("DEPLOIEMENT",1,"black")
        fenetre.blit(texte_phase,(612,594))
    elif phase==1:
        texte_phase=font.render("ATTAQUE",1,"black")
        fenetre.blit(texte_phase,(632,594))
    else:
        texte_phase=font.render("TRANSFERE",1,"black")
        fenetre.blit(texte_phase,(622,594))
    pygame.display.flip()

def test_continuer():
    """ void -> bool
    Préconidtions :
    Rôle : Test si le joueur continue la phase d'attaque / transfere"""
    passer=pygame.image.load("BouttonPasser.png").convert_alpha()
    fenetre.blit(passer,(6,588))
    affichage_info(2)
    pygame.display.flip()
    while True:
        for event in pygame.event.get():
            if event.type==MOUSEBUTTONDOWN :
                (x, y) = event.pos
                if 6<=x<=187 and 588<=y<=588+94:
                    return False
            if event.type == KEYDOWN:
                if event.key == K_RETURN :
                    return True

def affiche_defaite(joueur, joueur_gagnant, nombre_tour):
    """ Joueur, Joueur -> void
    Préconditions :
    Rôle : affichage de l'écran de défaite"""
    ecran_defaite = pygame.image.load("EcranDefaite.png").convert_alpha()
    fenetre.blit(ecran_defaite,(0,0))
    font = pygame.font.SysFont( " calibri " , 30 , bold = False , italic =False )
    nb_tour=str(nombre_tour)
    score0 = font.render( joueur.nom , 1 , "white" )
    score1 = font.render( str(joueur.atk_success) , 1 , "white" )
    score2 = font.render( str(joueur.def_success) , 1 , "white" )
    score3 = font.render( str(joueur.total_troupes) , 1 , "white" )
    score0_gagnant = font.render( joueur_gagnant.nom , 1 , "white" )
    score1_gagnant = font.render( str(joueur_gagnant.atk_success) , 1 , "white" )
    score2_gagnant = font.render( str(joueur_gagnant.def_success) , 1 , "white" )
    score3_gagnant = font.render( str(joueur_gagnant.total_troupes) , 1 , "white" )
    nb_tour= font.render( nb_tour , 1 , "white" )
    fenetre.blit ( score0 ,( 284 ,285 ) )
    fenetre.blit ( score1 ,( 284 ,379 ) )
    fenetre.blit ( score2 ,( 284 ,473 ) )
    fenetre.blit ( score3 ,( 284 ,545 ) )
    fenetre.blit ( score0_gagnant ,( 243 ,285 ) )
    fenetre.blit ( score1_gagnant ,( 981 ,379 ) )
    fenetre.blit ( score2_gagnant ,( 981 ,473 ) )
    fenetre.blit ( score3_gagnant ,( 981 ,545 ) )
    fenetre.blit ( nb_tour ,(646,236))
    pygame.display.flip()
    while True :
        for event in pygame.event.get():
            if event.type==QUIT: # clic sur la croix
                continuer = False # fin de la boucle
       
def affiche_victoire(joueur,nb_tour):
    """ Joueur, int -> void
    Préconditions :
    Rôle : affiche l'écran de victoire du joueur"""
    ecran_victoire = pygame.image.load("EcranVictoire.png").convert_alpha()
    fenetre.blit(ecran_victoire,(0,0))
    font = pygame.font.SysFont( " calibri " , 50 , bold = False , italic =
    False )
    nb_tour = font.render(str(nb_tours),True,(255,255,255))
    joueur = font.render(joueur.nom,True,(255,255,255))
    atk = font.render(str(joueur.atk_success), True, (255,255,255))
    defe = font.render(str(joueur.def_success),True,(255,255,255))
    trp = font.render(str(joueur.total_troupes),True,(255,255,255))
    fenetre.blit ( atk ,(875,367  ) )
    fenetre.blit ( defe ,(875,455  ) )
    fenetre.blit ( trp ,(875,550  ) )
    fenetre.blit ( joueur ,(805,273  ) )
    fenetre.blit(nb_tour,(285,259))
    pygame.display.flip()

def jeu(couleur_ID, nivAI):
    """ int, int -> void
    Préconditions : 0<=couleur_ID<=3, 1<=nivAI<=3
    Rôle : Partie de jeu"""
    try:
        global fond
        fenetre = pygame.display.set_mode((largeur,hauteur)) 
        fond = pygame.image.load("map.png").convert()
        fenetre.blit(fond,(0,0))
        liste_joueur=j.debut_partie("Joueur", couleur_ID, nivAI)
        affiche_boutton(liste_bouton, liste_joueur)
        pygame.display.flip()
        nb_tour=0
        continue_jeu=True
        while continue_jeu==True:
            joueur_perdu=0
            for joueur in liste_joueur:
                if joueur.total_troupes<1:
                    joueur_perdu+=1
            if joueur_perdu==3:
                continue_jeu=False
            else:
                liste_joueur=j.tour()
                nb_tour+=1
        if liste_joueur[0].total_troupes==0:
            for i in range(1,4):
                if liste_joueur[i].total_troupes>0:
                    affiche_defaite(liste_joueur[0],liste_joueur[i],nb_tour)
        else:
            affiche_victoire(liste_joueur[0],nb_tour)
        continuer = True
        while continuer:
            for event in pygame.event.get():
                if event.type==QUIT: # clic sur la croix
                    continuer = False # fin de la boucle                    
    finally:
        pygame.quit() # Fermeture de Pygame
